# FMCW-Radar-Simulator
# This project is not funed by any organization.

-----------------------------------------------------  
  Author: Lin Junyang   
  Email : liynjy@163.com  
  WeChat: liynjy
  Date  : 2019-6-15    
  All Rights Reserved.  
-----------------------------------------------------

1) This is a MATLAB based FMCW RF Radar Simulator. 
2) It generates FMCW radar for close handwave chirp level signal data. 
3) Your can try develop your radar data processing algorithm base on this simulator.
4) As a charllenge, can you develope your algorithm to detect the handwave directions: LEFT or RIGHT.
5) Run main.m in matlab to start trying out.


Author introduction: Lin Junyang
-- Radar Algorithm, Data Analysis expert
-- IC algorithm expert
-- FPGA, Embbed Systems expert

Contact me by Wechat:  liynjy
